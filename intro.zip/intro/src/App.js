import './App.css';
import { Os } from './components/os';

function App() {
  return (
    <div className="App">
      <Os />
    </div>
  );
}

export default App;
